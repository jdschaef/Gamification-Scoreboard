<?php
$message = "";
if(count($_POST)>0) {
$conn = mysql_connect("localhost","kib","guestguest");
if(!$conn) {
die("Connection failed: " . mysqli_connect_error());
}
mysql_select_db("sqlcdcsql",$conn);
$user =$_POST['userName'];
$pass =$_POST['password'];
$sql = "SELECT * FROM user WHERE usernames='$user' and passwords='$pass'";
//echo $sql;
$result = mysql_query($sql,$conn);
$count = mysql_num_rows($result);
if($count==0) {
$message = "Invalid Username or Password Database Will NOT Allow!";
//echo "No data for/n username: " .$_POST["userName"] . "/nPassword: " .$_POST["password"];
//echo $result;
} else {
$message = "Hm.. that login is correct... but what does that tell you?";
//echo "You got it";
}
}
?>
<html>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<body background="bio-hazard-wide-Red-Background.jpg">

<div style="line-height:1250%;">
    <br>
</div>


<form name="login" method="POST" action="">
<h1 align="center" colspan="2">Please Login</h1>
<div style="text-align:center;"><?php if ($message!="") {echo $message;} ?><div>
<table border = "0" cellpadding="10" cellspacing ="1" width ="500" align="center">
<tr class="tableheader">
</tr>
<tr class="tablerow">
<td align="right">Username</td>
<td><input type="text" name="userName"></td>
</tr>
<tr class="tablrow">
<td align="right">Password</td>
<td><input type="password" name="password"></td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2"><input type="submit" name="submit" value="Submit">
</tr>
</table>
</form>
</body>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</html>


