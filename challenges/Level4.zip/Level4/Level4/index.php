<?php
$message = "";
error_reporting(-1);
ini_set('display_errors','On');
if(count($_POST)>0) {
$conn = mysql_connect("localhost","kib","guestguest");
if(!$conn) {
die("Connection failed: " . mysqli_connect_error());
}
mysql_select_db("sqlcdcsql",$conn);
$sql = "SELECT * FROM user WHERE usernames='" .$_POST["userName"]."' and passwords= '".$_POST["password"]."'";
//echo $sql;
$result = mysql_query($sql,$conn);
$count = mysql_num_rows($result);
if($count==0) {
$message = "Invalid Username or Password Database Will NOT Allow!";
//echo "No data for/n username: " .$_POST["userName"] . "/nPassword: " .$_POST["password"];
//echo $result;
} else {
//$message = "You logged in as someone... Hm...";
$host  = $_SERVER['HTTP_HOST'];
$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = 'reward.html';
header("Location: http://$host$uri/$extra");
}
}
?>
<html>
<body bgcolor="#580000">
<div style="text-align:center;"><img src="zombie_apocalypse.jpg" align="center" alt="Hacker Banner" width="900px" height="200px"></div>
<form name="login" method="POST" action="">
<h1 align="center" colspan="2"><font color="white">Please Login</white></h1>
<div style="text-align:center;"><font color="white"><?php if ($message!="") {echo $message;} ?></font><div>
<table border = "0" cellpadding="10" cellspacing ="1" width ="500" align="center">
<tr class="tableheader">
</tr>
<tr class="tablerow">
<td align="right"><font color="white">Username</font></td>
<td><input type="text" name="userName"></td>
</tr>
<tr class="tablrow">
<td align="right"><font color="white">Password</font></td>
<td><input type="password" name="password"></td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2"><input type="submit" name="submit" value="Submit">
</tr>
</table>
</form>
</body>
</html>


