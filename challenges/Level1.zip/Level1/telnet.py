import getpass
import sys
import telnetlib
import base64

HOST = raw_input("IP Address of Telnet Sever: ")
user = 'Tim'
password = 'aWhvcGV5b3VkaWRudGNoZWF0'
passwort = base64.b64decode(password) 
tn = telnetlib.Telnet(HOST)

tn.read_until("login: ")
tn.write(user + "\n")
if password:
    tn.read_until("Password: ")
    tn.write(passwort + "\n")

tn.write("ls\n")
tn.write("exit\n")

print tn.read_all()
print("You Logged In!!")
print("Now check Wireshark to see if you caught the password")
