<head>
<div style="text-align:center;"><img src="banner2_1.jpg" align="center" alt="Hacker Banner" width="900px" height="200px"></div>
<meta charset="utf-8">
</head>
<body bgcolor="DEE7EF">
<div align="center">
<br><br>
<div style="width:700px"; "height:400px";>
<form action='nothere.html' method='POST'>
<fieldset >
<legend style="font-size:30px";>Login</legend>
<input type='hidden' name='submitted' id='submitted' value='1'/>
<label for='username' >Username:</label>
<input type='text' name='username' id='username'  maxlength="50" />
<label for='password' >Password:</label>
<input type='password' name='password' id='password' maxlength="50" />
<input type='submit' name='Submit' value='Submit' />
</fieldset>
</form>
</div>
</div>
<br>
<div align="center">
<?php
$page = $_GET['page'];
include($page);
?>
</div>
<nav>
<div align="center">
<a href="index.php?page=help.html">Ask to register</a>
<br>
<a href="index.php?page=signup.html">Sign Up for an Account</a>
</div>
</nav>
<?php
$page = $_POST['BadLogin'];
?>

